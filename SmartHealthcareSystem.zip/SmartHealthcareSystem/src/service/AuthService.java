
package service;

import model.*;
import java.util.Optional;

public class AuthService {

    private final InMemoryDB db = InMemoryDB.getInstance();

    public String registerUser(User u) {
        if (findUserByEmail(u.getEmail()).isPresent()) {
            return "\nEmail already registered";
        }
        db.addUser(u);
        return "\nUser Successfully Registered: " + u.getName();
    }

    public Optional<User> findUserByEmail(String email) {
        return db.getUsers().stream().filter(u -> u.getEmail().equalsIgnoreCase(email)).findFirst();
    }

    public Optional<User> login(String email, String password) {
        Optional<User> maybe = findUserByEmail(email);
        if (maybe.isEmpty()) {
            return Optional.empty();
        }
        User u = maybe.get();
        if (!u.getPassword().equals(password)) {
            return Optional.empty();
        }
        return maybe;
    }
}
