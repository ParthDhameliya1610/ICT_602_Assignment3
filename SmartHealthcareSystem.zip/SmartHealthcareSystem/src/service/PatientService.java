package service;

import model.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.*;
import java.util.stream.Collectors;

public class PatientService {

    private final InMemoryDB db = InMemoryDB.getInstance();

    // Get all available doctors (with available slots)
    public List<Doctor> getAvailableDoctors() {
        return db.getUsers().stream()
                .filter(u -> u instanceof Doctor)
                .map(u -> (Doctor) u)
                .filter(d -> db.getAvailabilities().stream()
                        .anyMatch(a -> a.getDoctorEmail().equalsIgnoreCase(d.getEmail()) && a.isAvailable()))
                .collect(Collectors.toList());
    }

    // Book appointment
    public boolean bookAppointment(String patientEmail, String doctorName, String diagnose,
                                   String dateStr, String timeStr) {
        try {
            LocalDate date = LocalDate.parse(dateStr);
            LocalTime time = LocalTime.parse(timeStr);

            Optional<Doctor> doctorOpt = db.getUsers().stream()
                    .filter(u -> u instanceof Doctor && u.getName().equalsIgnoreCase(doctorName))
                    .map(u -> (Doctor) u)
                    .findFirst();

            if (doctorOpt.isEmpty()) {
                System.out.println("\nDoctor not found: " + doctorName);
                return false;
            }

            String doctorEmail = doctorOpt.get().getEmail();

            Optional<DoctorAvailability> slot = db.getAvailabilities().stream()
                    .filter(a -> a.getDoctorEmail().equalsIgnoreCase(doctorEmail)
                            && a.getDate().equals(date)
                            && a.getTime().equals(time)
                            && a.isAvailable())
                    .findFirst();

            if (slot.isEmpty()) {
                System.out.println("\nSlot not available.");
                return false;
            }

            Appointment ap = new Appointment(patientEmail, doctorEmail, diagnose, date, time);
            db.addAppointment(ap);
            slot.get().setAvailable(false);
            System.out.println("\nAppointment booked successfully with Dr. " + doctorName);
            return true;

        } catch (Exception e) {
            System.out.println("Error booking appointment: " + e.getMessage());
            return false;
        }
    }

    // View appointment history
    public void viewAppointments(String patientEmail) {
        List<Appointment> list = db.getAppointments().stream()
                .filter(a -> a.getPatientEmail().equalsIgnoreCase(patientEmail))
                .collect(Collectors.toList());

        if (list.isEmpty()) {
            System.out.println("\nNo appointments found.");
            return;
        }

        System.out.printf("%-20s %-20s %-20s %-20s %-20s%n",
                "Patient", "Doctor", "Diagnosis", "Prescription", "Date");
        for (Appointment a : list) {
            String doctorName = db.getUsers().stream()
                    .filter(u -> u instanceof Doctor && u.getEmail().equalsIgnoreCase(a.getDoctorEmail()))
                    .map(User::getName)
                    .findFirst()
                    .orElse("Unknown Doctor");

            System.out.printf("%-20s %-20s %-20s %-20s %-20s%n",
                    a.getPatientEmail(), doctorName, a.getDiagnose(),
                    (a.getPrescription() == null ? "-" : a.getPrescription()), a.getDate());
        }
    }

    // Update patient profile
    public void updateProfile(Patient patient, String newEmail, String newPhone, String newPassword) {
        if (newEmail != null && !newEmail.isBlank()) patient.setEmail(newEmail);
        if (newPhone != null && !newPhone.isBlank()) patient.setPhone(newPhone);
        if (newPassword != null && !newPassword.isBlank()) patient.setPassword(newPassword);
        System.out.println("\nProfile updated successfully.");
    }

    //Reschedule existing appointment
    public boolean rescheduleAppointmentByDoctorName(String patientEmail, String doctorName,
                                                     String newDateStr, String newTimeStr) {
        try {
            LocalDate newDate = LocalDate.parse(newDateStr);
            LocalTime newTime = LocalTime.parse(newTimeStr);

            Optional<User> doctorOpt = db.getUsers().stream()
                    .filter(u -> u instanceof Doctor && u.getName().equalsIgnoreCase(doctorName))
                    .findFirst();

            if (doctorOpt.isEmpty()) {
                System.out.println("Doctor not found with name: " + doctorName);
                return false;
            }

            String doctorEmail = doctorOpt.get().getEmail();

            Optional<Appointment> apOpt = db.getAppointments().stream()
                    .filter(a -> a.getPatientEmail().equalsIgnoreCase(patientEmail)
                            && a.getDoctorEmail().equalsIgnoreCase(doctorEmail))
                    .findFirst();

            if (apOpt.isEmpty()) {
                System.out.println("\nAppointment not found to reschedule.");
                return false;
            }

            Appointment ap = apOpt.get();

            // Free old slot
            db.getAvailabilities().stream()
                    .filter(a -> a.getDoctorEmail().equalsIgnoreCase(doctorEmail)
                            && a.getDate().equals(ap.getDate())
                            && a.getTime().equals(ap.getTime()))
                    .findFirst()
                    .ifPresent(a -> a.setAvailable(true));

            // Reserve new slot
            Optional<DoctorAvailability> newSlot = db.getAvailabilities().stream()
                    .filter(a -> a.getDoctorEmail().equalsIgnoreCase(doctorEmail)
                            && a.getDate().equals(newDate)
                            && a.getTime().equals(newTime)
                            && a.isAvailable())
                    .findFirst();

            if (newSlot.isEmpty()) {
                System.out.println("\nRequested new slot is not available.");
                return false;
            }

            newSlot.get().setAvailable(false);

            ap.setDate(newDate);
            ap.setTime(newTime);
            System.out.println("\nAppointment rescheduled successfully with Dr. " + doctorName);
            return true;

        } catch (Exception e) {
            System.out.println("\nError while rescheduling: " + e.getMessage());
            return false;
        }
    }

    //Cancel appointment
    public boolean cancelAppointmentByDoctorName(String patientEmail, String doctorName) {
        Optional<User> doctorOpt = db.getUsers().stream()
                .filter(u -> u instanceof Doctor && u.getName().equalsIgnoreCase(doctorName))
                .findFirst();

        if (doctorOpt.isEmpty()) {
            System.out.println("Doctor not found with name: " + doctorName);
            return false;
        }

        String doctorEmail = doctorOpt.get().getEmail();

        Optional<Appointment> apOpt = db.getAppointments().stream()
                .filter(a -> a.getPatientEmail().equalsIgnoreCase(patientEmail)
                        && a.getDoctorEmail().equalsIgnoreCase(doctorEmail))
                .findFirst();

        if (apOpt.isPresent()) {
            Appointment ap = apOpt.get();
            LocalDate date = ap.getDate();
            LocalTime time = ap.getTime();

            // Remove appointment
            db.removeAppointment(ap);

            // Restore doctor's availability
            db.getAvailabilities().stream()
                    .filter(a -> a.getDoctorEmail().equalsIgnoreCase(doctorEmail)
                            && a.getDate().equals(date)
                            && a.getTime().equals(time))
                    .findFirst()
                    .ifPresent(a -> a.setAvailable(true));

            System.out.println("\nAppointment canceled successfully with Dr. " + doctorName);
            return true;
        } else {
            System.out.println("\nAppointment not found with Dr. " + doctorName);
            return false;
        }
    }
}
