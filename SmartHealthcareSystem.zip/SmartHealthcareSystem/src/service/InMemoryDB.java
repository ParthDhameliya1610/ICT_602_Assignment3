package service;

import model.*;
import java.util.ArrayList;
import java.util.List;
import java.time.LocalDate;

public class InMemoryDB {

    private static final InMemoryDB INSTANCE = new InMemoryDB();

    private final List<User> users = new ArrayList<>();
    private final List<DoctorAvailability> availabilities = new ArrayList<>();
    private final List<Appointment> appointments = new ArrayList<>();    
    public static List<Doctor> doctors = new ArrayList<>();
    public static List<Patient> patients = new ArrayList<>();
   

    private InMemoryDB() {
        // default admin details
        users.add(new Admin("System Admin", "admin@health.com", "0000000000", "admin123"));
    }

    public static InMemoryDB getInstance() {
        return INSTANCE;
    }

    public List<User> getUsers() {
        return users;
    }

    public List<DoctorAvailability> getAvailabilities() {
        return availabilities;
    }

    public List<Appointment> getAppointments() {
        return appointments;
    }

    // convenience helpers
    public void addUser(User u) {
        users.add(u);
    }

    public void addAvailability(DoctorAvailability a) {
        availabilities.add(a);
    }

    public void addAppointment(Appointment a) {
        appointments.add(a);
    }

    public void removeAppointment(Appointment a) {
        appointments.remove(a);
    }

    public void removeUser(User u) {
        users.remove(u);
    }
}
