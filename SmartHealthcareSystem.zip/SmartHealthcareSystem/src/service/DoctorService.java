package service;

import model.*;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class DoctorService {

    private final InMemoryDB db = InMemoryDB.getInstance();

    // Get all appointments for a specific doctor
    public List<Appointment> getAppointmentsForDoctor(String doctorEmail) {
        return db.getAppointments().stream()
                .filter(a -> a.getDoctorEmail().equalsIgnoreCase(doctorEmail))
                .collect(Collectors.toList());
    }

    // Add prescription if not already set
    public boolean addPrescription(String doctorEmail, String patientEmail, String prescriptionText) {
        Optional<Appointment> ap = db.getAppointments().stream()
                .filter(a -> a.getDoctorEmail().equalsIgnoreCase(doctorEmail)
                        && a.getPatientEmail().equalsIgnoreCase(patientEmail))
                .findFirst();

        if (ap.isPresent()) {
            ap.get().setPrescription(prescriptionText);
            System.out.println("\nPrescription added successfully.");
            return true;
        } else {
            System.out.println("\nAppointment not found for given doctor & patient.");
            return false;
        }
    }

    // Update existing prescription
    public boolean updatePrescription(String doctorEmail, String patientEmail, String prescriptionText) {
        Optional<Appointment> ap = db.getAppointments().stream()
                .filter(a -> a.getDoctorEmail().equalsIgnoreCase(doctorEmail)
                        && a.getPatientEmail().equalsIgnoreCase(patientEmail))
                .findFirst();

        if (ap.isPresent()) {
            ap.get().setPrescription(prescriptionText);
            System.out.println("\nPrescription updated successfully.");
            return true;
        } else {
            System.out.println("\nAppointment not found for given doctor & patient.");
            return false;
        }
    }

    // Combine add and update in one method (used by DoctorMenuView)
    public void addOrUpdatePrescription(String doctorEmail, String patientEmail, String prescriptionText) {
        Optional<Appointment> apOpt = db.getAppointments().stream()
                .filter(a -> a.getDoctorEmail().equalsIgnoreCase(doctorEmail)
                        && a.getPatientEmail().equalsIgnoreCase(patientEmail))
                .findFirst();

        if (apOpt.isEmpty()) {
            throw new IllegalArgumentException("No appointment found between this doctor and patient.");
        }

        Appointment ap = apOpt.get();
        ap.setPrescription(prescriptionText);
        System.out.println("\nPrescription added/updated successfully for " + patientEmail);
    }
}
