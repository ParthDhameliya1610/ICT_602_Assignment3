package service;

import model.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

public class AdminService {

    private final InMemoryDB db = InMemoryDB.getInstance();

    //List all doctors
    public List<Doctor> getAllDoctors() {
        return db.getUsers().stream()
                .filter(u -> u instanceof Doctor)
                .map(u -> (Doctor) u)
                .toList();
    }

    //List all patients
    public List<Patient> getAllPatients() {
        return db.getUsers().stream()
                .filter(u -> u instanceof Patient)
                .map(u -> (Patient) u)
                .toList();
    }

    //Add doctor availability
    public void addDoctorAvailability(String doctorEmail, LocalTime time, LocalDate date) {
        Optional<User> userOpt = db.getUsers().stream()
                .filter(u -> u.getEmail().equalsIgnoreCase(doctorEmail))
                .findFirst();

        if (userOpt.isEmpty() || !(userOpt.get() instanceof Doctor)) {
            throw new IllegalArgumentException("Doctor not found with email: " + doctorEmail);
        }

        DoctorAvailability availability = new DoctorAvailability(doctorEmail, time, date, true);
        db.addAvailability(availability);
    }

    //Optional string-based version
    public boolean setDoctorAvailability(String doctorEmail, String timeStr, String dateStr) {
        try {
            LocalTime time = LocalTime.parse(timeStr);
            LocalDate date = LocalDate.parse(dateStr);
            addDoctorAvailability(doctorEmail, time, date);
            return true;
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
            return false;
        }
    }

    // Delete a doctor by name
    public boolean deleteDoctorByName(String name) {
        Optional<User> doctorOpt = db.getUsers().stream()
                .filter(u -> u instanceof Doctor && u.getName().equalsIgnoreCase(name))
                .findFirst();

        if (doctorOpt.isPresent()) {
            String email = doctorOpt.get().getEmail();
            db.getUsers().remove(doctorOpt.get());
            db.getAvailabilities().removeIf(a -> a.getDoctorEmail().equalsIgnoreCase(email));
            db.getAppointments().removeIf(a -> a.getDoctorEmail().equalsIgnoreCase(email));
            return true;
        }
        return false;
    }

    //Delete a patient by name
    public boolean deletePatientByName(String name) {
        Optional<User> patientOpt = db.getUsers().stream()
                .filter(u -> u instanceof Patient && u.getName().equalsIgnoreCase(name))
                .findFirst();

        if (patientOpt.isPresent()) {
            String email = patientOpt.get().getEmail();
            db.getUsers().remove(patientOpt.get());
            db.getAppointments().removeIf(a -> a.getPatientEmail().equalsIgnoreCase(email));
            return true;
        }
        return false;
    }

    //Display all appointments
    public void displayAppointments() {
        System.out.println("\nAll Appointments");
        for (Appointment appt : db.getAppointments()) {
            System.out.println(appt);
        }
    }

    //Display all patients
    public void displayPatients() {
        System.out.println("\nRegistered Patients");
        getAllPatients().forEach(System.out::println);
    }

    //Return all appointments
    public List<Appointment> getAllAppointments() {
        return db.getAppointments();
    }
}
