
package test;

import model.*;
import service.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

public class AdminServiceTest {
    
    private AdminService adminService;
    private InMemoryDB db;
    
    @BeforeEach
    public void setUp() {
        adminService = new AdminService();
        db = InMemoryDB.getInstance();
        // Clear existing data
        db.getUsers().clear();
        db.getAvailabilities().clear();
        db.getAppointments().clear();
        db.getUsers().add(new Admin("System Admin", "admin@health.com", "0000000000", "admin123"));
    }
    
    @Test
    public void testDoctorManagement() {
        // Add doctors
        Doctor doctor1 = new Doctor("maxwell", "maxwell@gmail.com", "9874512451", "max4455", "Cardiology");
        Doctor doctor2 = new Doctor("martin", "martin@gmail.com", "9875412563", "martin951", "Neurology");
        db.addUser(doctor1);
        db.addUser(doctor2);
        
        // Test get all doctors
        List<Doctor> doctors = adminService.getAllDoctors();
        assertEquals(2, doctors.size());
        
        // Test add doctor availability
        adminService.addDoctorAvailability("maxwell@gmail.com", LocalTime.of(10, 0), LocalDate.of(2024, 12, 15));
        assertEquals(1, db.getAvailabilities().size());
        
        // Test delete doctor
        boolean deleted = adminService.deleteDoctorByName("Maxwell");
        assertTrue(deleted);
        assertEquals(1, adminService.getAllDoctors().size());
        assertEquals(0, db.getAvailabilities().size());
    }
    
    @Test
    public void testPatientManagement() {
        // Add patients
        Patient patient1 = new Patient("deepak", "deepak@gmail.com", "8574123623", "deepak", LocalDate.of(1990, 1, 1));
        Patient patient2 = new Patient("shane", "shane@gmail.com", "9586235412", "shane3838", LocalDate.of(1985, 1, 1));
        db.addUser(patient1);
        db.addUser(patient2);
        
        // Test get all patients
        List<Patient> patients = adminService.getAllPatients();
        assertEquals(2, patients.size());
        
        // Test delete patient
        boolean deleted = adminService.deletePatientByName("deepak");
        assertTrue(deleted);
        assertEquals(1, adminService.getAllPatients().size());
    }
}
