package test;

import model.*;
import service.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

public class AcceptanceTest {
    
    private AuthService authService;
    private AdminService adminService;
    private PatientService patientService;
    private DoctorService doctorService;
    private InMemoryDB db;
    
    @BeforeEach
    public void setUp() {
        authService = new AuthService();
        adminService = new AdminService();
        patientService = new PatientService();
        doctorService = new DoctorService();
        db = InMemoryDB.getInstance();
        
        // Reset system
        db.getUsers().clear();
        db.getAvailabilities().clear();
        db.getAppointments().clear();
        db.getUsers().add(new Admin("System Admin", "admin@health.com", "0000000000", "admin123"));
    }
    
    @Test
    public void testPatientCanRegisterAndBookAppointment() {
        // A healthcare system with available doctors
        Doctor doctor = new Doctor("Dr. Smith", "smith@hospital.com", "8546231423", "556622", "Cardiology");
        authService.registerUser(doctor);
        adminService.addDoctorAvailability("smith@hospital.com", LocalTime.of(10, 0), LocalDate.of(2024, 12, 15));
        
        // A new patient registers and logs in
        Patient patient = new Patient("inglish", "inglish@email.com", "9513578426", "95123", LocalDate.of(1985, 5, 15));
        String registrationResult = authService.registerUser(patient);
        Optional<User> loginResult = authService.login("inglish@email.com", "95123");
        
        // Registration and login should be successful
        assertTrue(registrationResult.contains("Successfully Registered"));
        assertTrue(loginResult.isPresent());
        assertTrue(loginResult.get() instanceof Patient);
        
        // Patient views available doctors and books appointment
        List<Doctor> availableDoctors = patientService.getAvailableDoctors();        
        boolean bookingResult = patientService.bookAppointment("inglish@email.com", "Dr. Smith", "Chest pain consultation", "2024-12-15", "10:00");
        
        // Then: Appointment should be booked successfully
        assertEquals(1, availableDoctors.size());
        assertTrue(bookingResult);
        assertEquals(1, db.getAppointments().size());
    }
    
    @Test
    public void testDoctorCanManagePatientAppointments() {
        // A doctor with scheduled patients
        Doctor doctor = new Doctor("Dr. Martinez", "martinez@hospital.com", "1111111111", "docpass", "Pediatrics");
        Patient patient = new Patient("Emma Wilson", "emma@email.com", "2222222222", "password", LocalDate.of(2010, 8, 15));
        
        authService.registerUser(doctor);
        authService.registerUser(patient);
        
        adminService.addDoctorAvailability("martinez@hospital.com", LocalTime.of(10, 0), LocalDate.of(2024, 12, 22));
        
        patientService.bookAppointment("emma@email.com", "Dr. Martinez", "Vaccination", "2024-12-22", "10:00");
        
        // Doctor logs in and views appointments
        Optional<User> doctorLogin = authService.login("martinez@hospital.com", "docpass");
        List<Appointment> appointments = doctorService.getAppointmentsForDoctor("martinez@hospital.com");
        
        // Doctor should see patient appointments
        assertTrue(doctorLogin.isPresent());
        assertTrue(doctorLogin.get() instanceof Doctor);
        assertEquals(1, appointments.size());
        assertEquals("emma@email.com", appointments.get(0).getPatientEmail());
        
        // Doctor adds prescription
        doctorService.addOrUpdatePrescription("martinez@hospital.com", "emma@email.com", "Administered MMR vaccine");
        
        // Prescription should be saved
        assertEquals("Administered MMR vaccine", appointments.get(0).getPrescription());
    }
    
    @Test
    public void testAdminCanManageHealthcareSystem() {
        // An admin user
        Optional<User> adminLogin = authService.login("admin@health.com", "admin123");
        assertTrue(adminLogin.isPresent());
        assertTrue(adminLogin.get() instanceof Admin);
        
        // Admin registers doctors and patients
        Doctor doctor1 = new Doctor("Dr. Heart", "heart@hospital.com", "7451245123", "h2453", "Cardiology");
        Doctor doctor2 = new Doctor("Dr. Brain", "brain@hospital.com", "9562386523", "br5890", "Neurology");
        Patient patient = new Patient("Sarah Connor", "sarah@email.com", "9584756235", "srd345", LocalDate.of(1975, 8, 29));
        
        authService.registerUser(doctor1);
        authService.registerUser(doctor2);
        authService.registerUser(patient);
        
        // Then: All users should be registered
        assertEquals(2, adminService.getAllDoctors().size());
        assertEquals(1, adminService.getAllPatients().size());
        
        // Admin sets up schedules and patient books appointment
        adminService.addDoctorAvailability("heart@hospital.com", LocalTime.of(9, 0), LocalDate.of(2024, 12, 23));
        
        patientService.bookAppointment("sarah@email.com", "Dr. Heart", "Chest pain", "2024-12-23", "09:00");
        
        //Admin can view all appointments
        List<Appointment> appointments = adminService.getAllAppointments();
        assertEquals(1, appointments.size());
        
        // Admin removes a doctor
        // Use correct doctor name as registered
        boolean doctorRemoved = adminService.deleteDoctorByName("Dr. Heart");
        
        // Doctor and related data should be removed
        assertTrue(doctorRemoved);
        assertEquals(1, adminService.getAllDoctors().size());
        assertEquals(0, adminService.getAllAppointments().size()); // Appointment should be removed with doctor
    }
}
