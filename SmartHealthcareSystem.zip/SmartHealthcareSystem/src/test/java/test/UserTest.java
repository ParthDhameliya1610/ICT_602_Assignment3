package test;

import model.*;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.time.LocalDate;

public class UserTest {
    
    @Test
    public void testUserCreation() {
        // Test Admin creation
        Admin admin = new Admin("james", "james@gmail.com", "9874512362", "james123");
        assertEquals("james", admin.getName());
        assertEquals("james@gmail.com", admin.getEmail());
        
        // Test Doctor creation
        Doctor doctor = new Doctor("maxwell", "max@gmail.com", "9874587895", "max@007", "Cardiology");
        assertEquals("maxwell", doctor.getName());
        assertEquals("Cardiology", doctor.getSpecialist());
        
        // Test Patient creation
        LocalDate dob = LocalDate.of(1990, 5, 15);
        Patient patient = new Patient("deepak", "patient@test.com", "1234567890", "password", dob);
        assertEquals("deepak", patient.getName());
        assertEquals(dob, patient.getDob());
    }
    
    @Test
    public void testEmailLowerCase() {
        Admin admin = new Admin("james", "JAMES@GMAIL.COM", "9874512362", "james123");
        assertEquals("james@gmail.com", admin.getEmail());
        
        admin.setEmail("NEW@EMAIL.COM");
        assertEquals("new@email.com", admin.getEmail());
    }
}
