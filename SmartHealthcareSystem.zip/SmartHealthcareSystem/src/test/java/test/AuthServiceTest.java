
package test;

import model.*;
import service.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.time.LocalDate;
import java.util.Optional;

public class AuthServiceTest {
    
    private AuthService authService;
    private InMemoryDB db;
    
    @BeforeEach
    public void setUp() {
        authService = new AuthService();
        db = InMemoryDB.getInstance();
        // Clear existing users except default admin
        db.getUsers().clear();
        db.getUsers().add(new Admin("System Admin", "admin@health.com", "0000000000", "admin123"));
    }
    
    @Test
    public void testUserRegistrationAndLogin() {
        // Test successful registration
        Patient patient = new Patient("deepak", "deepak@gmail.com", "9574123562", "deepak009", LocalDate.of(1990, 10, 20));
        String result = authService.registerUser(patient);
        assertTrue(result.contains("Successfully Registered"));
        
        // Test duplicate email registration
        Patient duplicate = new Patient("deepak", "deepak@gmail.com", "9852145213", "deepak009", LocalDate.of(1985, 1, 10));
        String duplicateResult = authService.registerUser(duplicate);
        assertEquals("\nEmail already registered", duplicateResult);
        
        // Test successful login
        Optional<User> loginResult = authService.login("deepak@gmail.com", "deepak009");
        assertTrue(loginResult.isPresent());
        assertEquals("deepak", loginResult.get().getName());
        
        // Test failed login
        Optional<User> failedLogin = authService.login("deepak@gmail.com", "deep");
        assertFalse(failedLogin.isPresent());
    }
}
