package test;

import model.*;
import service.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

public class SystemTest {
    
    private AuthService authService;
    private AdminService adminService;
    private PatientService patientService;
    private DoctorService doctorService;
    private InMemoryDB db;
    
    @BeforeEach
    public void setUp() {
        authService = new AuthService();
        adminService = new AdminService();
        patientService = new PatientService();
        doctorService = new DoctorService();
        db = InMemoryDB.getInstance();
        
        // Reset system
        db.getUsers().clear();
        db.getAvailabilities().clear();
        db.getAppointments().clear();
        db.getUsers().add(new Admin("System Admin", "admin@health.com", "0000000000", "admin123"));
    }
    
    @Test
    public void testCompleteHealthcareSystemWorkflow() {
        // Register multiple users
        Doctor cameron = new Doctor("Cameron", "cameron@hospital.com", "1111111111", "password", "Cardiology");
        Doctor mitchell = new Doctor("Mitchell", "mitchell@hospital.com", "2222222222", "password", "Neurology");
        Patient travis = new Patient("Travis", "travis@email.com", "4444444444", "password", LocalDate.of(1985, 3, 15));
        Patient cooper = new Patient("Cooper", "cooper@email.com", "5555555555", "password", LocalDate.of(1990, 7, 22));
        
        authService.registerUser(cameron);
        authService.registerUser(mitchell);
        authService.registerUser(travis);
        authService.registerUser(cooper);
        
        // Admin sets up schedules
        adminService.addDoctorAvailability("cameron@hospital.com", LocalTime.of(9, 0), LocalDate.of(2024, 12, 15));
        adminService.addDoctorAvailability("mitchell@hospital.com", LocalTime.of(11, 0), LocalDate.of(2024, 12, 16));
        
        // Patients book appointments
        boolean booking1 = patientService.bookAppointment("travis@email.com", "Cameron", "Chest pain", "2024-12-15", "09:00");
        boolean booking2 = patientService.bookAppointment("cooper@email.com", "Mitchell", "Headaches", "2024-12-16", "11:00");
        
        assertTrue(booking1);
        assertTrue(booking2);
        assertEquals(2, db.getAppointments().size());
        
        // Doctors manage appointments
        doctorService.addOrUpdatePrescription("cameron@hospital.com", "travis@email.com", "Prescribed heart medication");
        doctorService.addOrUpdatePrescription("mitchell@hospital.com", "cooper@email.com", "Rest and pain relief recommended");
        
        // Verify system state
        assertEquals(5, db.getUsers().size());
        assertEquals(2, adminService.getAllDoctors().size());
        assertEquals(2, adminService.getAllPatients().size());
        assertEquals(2, adminService.getAllAppointments().size());
    }
    
    @Test
    public void testSystemErrorHandling() {
        // Test invalid login
        Optional<User> invalidLogin = authService.login("nonexistent@email.com", "password");
        assertFalse(invalidLogin.isPresent());
        
        // Test duplicate email registration
        Patient abbot = new Patient("Abbot", "abbot@gmail.com", "1111111111", "password", LocalDate.of(1990, 1, 1));
        Patient owen = new Patient("Owen", "abbot@gmail.com", "2222222222", "password", LocalDate.of(1985, 1, 1));
        
        String result1 = authService.registerUser(abbot);
        String result2 = authService.registerUser(owen);
        
        assertTrue(result1.contains("Successfully Registered"));
        assertEquals("\nEmail already registered", result2);
        
        // Test booking with non-existent doctor
        boolean invalidBooking = patientService.bookAppointment("abbot@gmail.com", "Non Existent Doctor", "Checkup", "2024-12-15", "10:00");
        assertFalse(invalidBooking);
        
        // Test double booking same slot
        Doctor cameron = new Doctor("Cameron", "cameron@hospital.com", "1111111111", "password", "General");
        authService.registerUser(cameron);
        adminService.addDoctorAvailability("cameron@hospital.com", LocalTime.of(10, 0), LocalDate.of(2024, 12, 15));
        
        Patient travis = new Patient("Travis", "travis@gmail.com", "3333333333", "password", LocalDate.of(1985, 1, 1));
        authService.registerUser(travis);
        
        boolean firstBooking = patientService.bookAppointment("abbot@gmail.com", "Cameron", "Checkup", "2024-12-15", "10:00");
        boolean secondBooking = patientService.bookAppointment("travis@gmail.com", "Cameron", "Checkup", "2024-12-15", "10:00");
        
        assertTrue(firstBooking);
        assertFalse(secondBooking);
    }
}
