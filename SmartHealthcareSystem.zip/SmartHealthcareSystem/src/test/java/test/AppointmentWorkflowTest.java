package test;

import model.*;
import service.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

public class AppointmentWorkflowTest {
    
    private AuthService authService;
    private AdminService adminService;
    private PatientService patientService;
    private DoctorService doctorService;
    private InMemoryDB db;
    
    @BeforeEach
    public void setUp() {
        authService = new AuthService();
        adminService = new AdminService();
        patientService = new PatientService();
        doctorService = new DoctorService();
        db = InMemoryDB.getInstance();
        
        // Clear existing data
        db.getUsers().clear();
        db.getAvailabilities().clear();
        db.getAppointments().clear();
        db.getUsers().add(new Admin("System Admin", "admin@health.com", "0000000000", "admin123"));
    }
    
    @Test
    public void testCompleteAppointmentBookingWorkflow() {
        // Register users
        Patient patient = new Patient("deepak", "deepak@gmail.com", "8754126352", "deepak7809", LocalDate.of(1990, 10, 21));
        Doctor doctor = new Doctor("maxwell", "maxwell@gmail.com", "8753264123", "maxi342", "Cardiology");
        
        authService.registerUser(patient);
        authService.registerUser(doctor);
        
        // Admin adds doctor availability
        adminService.addDoctorAvailability("maxwell@gmail.com", LocalTime.of(10, 0), LocalDate.of(2024, 12, 15));
        
        // Patient views available doctors
        List<Doctor> availableDoctors = patientService.getAvailableDoctors();
        assertEquals(1, availableDoctors.size());
        assertEquals("maxwell", availableDoctors.get(0).getName());
        
        // Patient books appointment
        boolean bookingResult = patientService.bookAppointment("deepak@gmail.com", "maxwell", "Regular checkup", "2024-12-15", "10:00");
        assertTrue(bookingResult);
        assertEquals(1, db.getAppointments().size());
        
        // FIX 1: Use correct doctor email for getting appointments
        List<Appointment> doctorAppointments = doctorService.getAppointmentsForDoctor("maxwell@gmail.com");
        assertEquals(1, doctorAppointments.size());
        
        // Doctor adds prescription
        doctorService.addOrUpdatePrescription("maxwell@gmail.com", "deepak@gmail.com", "Take rest and drink water");
        assertEquals("Take rest and drink water", doctorAppointments.get(0).getPrescription());
    }
    
    @Test
    public void testAppointmentReschedulingAndCancellation() {        
        Patient patient = new Patient("Ellis", "ellis@gmail.com", "9586247562", "ellis2121", LocalDate.of(1985, 6, 15));
        Doctor doctor = new Doctor("ricky", "ricky@gmail.com", "9586241235", "ricky43", "Neurology");
        
        authService.registerUser(patient);
        authService.registerUser(doctor);
        
        // Add availability and book appointment
        adminService.addDoctorAvailability("ricky@gmail.com", LocalTime.of(11, 0), LocalDate.of(2024, 12, 20));
        patientService.bookAppointment("ellis@gmail.com", "ricky", "Headache consultation", "2024-12-20", "11:00");
        
        assertEquals(1, db.getAppointments().size());
        
        // Add availability for the DOCTOR
        adminService.addDoctorAvailability("ricky@gmail.com", LocalTime.of(14, 0), LocalDate.of(2024, 12, 21));        
        
        boolean rescheduleResult = patientService.rescheduleAppointmentByDoctorName("ellis@gmail.com", "ricky", "2024-12-21", "14:00");
        assertTrue(rescheduleResult);
        
        // Cancellation
        boolean cancelResult = patientService.cancelAppointmentByDoctorName("ellis@gmail.com", "ricky");
        assertTrue(cancelResult);
        assertEquals(0, db.getAppointments().size());
    }
}
