
package test;

// ValidationTest.java
import service.ValidationService;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ValidationTest {
    
    @Test
    public void testEmailValidation() {
        // Valid emails
        assertTrue(ValidationService.isValidEmail("test@gmail.com"));
        assertTrue(ValidationService.isValidEmail("user.name@domain.co.au"));
        
        // Invalid emails
        assertFalse(ValidationService.isValidEmail(null));
        assertFalse(ValidationService.isValidEmail("invalid-email"));
        assertFalse(ValidationService.isValidEmail("@domain.com"));
        assertFalse(ValidationService.isValidEmail("user@"));
    }
    
    @Test
    public void testPhoneValidation() {
        // Valid phones
        assertTrue(ValidationService.isValidPhone("8475125623"));
        assertTrue(ValidationService.isValidPhone("987451256234578"));
        
        // Invalid phones
        assertFalse(ValidationService.isValidPhone(null));
        assertFalse(ValidationService.isValidPhone("852369")); 
        assertFalse(ValidationService.isValidPhone("9851247852354862"));
        assertFalse(ValidationService.isValidPhone("956421l54k"));
    }
}

