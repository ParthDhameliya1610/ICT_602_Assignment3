
package com.mycompany.smarthealthcaresystem;



import view.MainMenuView;

public class SmartHealthCareSystem {
    public static void main(String[] args) {
        new MainMenuView().displayMainMenu();
    }
}

