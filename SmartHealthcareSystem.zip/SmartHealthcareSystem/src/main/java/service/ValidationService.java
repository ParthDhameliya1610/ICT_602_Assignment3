
package service;

public class ValidationService {

    public static boolean isValidEmail(String email) {
        if (email == null || email.isEmpty()) {
            return false;
        }
        
        // Must contain both @ and .
        if (!email.contains("@") || !email.contains(".")) {
            return false;
        }
        
        // @ must come before
        int atPos = email.indexOf("@");
        int dotPos = email.lastIndexOf(".");        
        
        return atPos > 0 && dotPos > atPos + 1 && dotPos < email.length() - 1;
    }

    public static boolean isValidPhone(String phone) {
        return phone != null && phone.matches("\\d{7,15}");
    }
}

