
package controller;




import model.*;
import service.*;
import java.util.*;

public class DoctorController {
    private DoctorService doctorService = new DoctorService();

    public void viewPatients(String doctorName) {
        List<Appointment> list = doctorService.getAppointmentsForDoctor(doctorName);
        if (list.isEmpty()) {
            System.out.println("No patients assigned.");
        } else {
            System.out.println("Patient Name | Diagnose | Time | Date | Prescription");
            for (Appointment a : list) System.out.println(a);
        }
    }

    public void addPrescription(String doctorName, String patientName, String prescriptionText) {
        boolean added = doctorService.addPrescription(doctorName, patientName, prescriptionText);
        System.out.println(added ? "Prescription added successfully!" : "Appointment not found!");
    }

    public void updatePrescription(String doctorName, String patientName, String prescriptionText) {
        boolean updated = doctorService.updatePrescription(doctorName, patientName, prescriptionText);
        System.out.println(updated ? "Prescription updated successfully!" : "Prescription not found!");
    }
}
