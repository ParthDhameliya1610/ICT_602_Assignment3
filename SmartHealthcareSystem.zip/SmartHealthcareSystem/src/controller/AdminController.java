package controller;

import model.*;
import service.*;
import java.util.*;

public class AdminController {
    private AdminService adminService = new AdminService();

    public void displayAllDoctors() {
        List<Doctor> doctors = adminService.getAllDoctors();
        if (doctors.isEmpty()) {
            System.out.println("No doctors found.");
        } else {
            System.out.println("Doctor Name       | Specialist      | Time           | Date           | Available");
            System.out.println("--------------------------------------------------------------------------");
            for (Doctor d : doctors) {
                System.out.println(d);
            }
        }
    }

    public void addDoctorAvailability(String name, String time, String date) {
        boolean updated = adminService.setDoctorAvailability(name, time, date);
        if (updated) System.out.println("Doctor availability added successfully!");
        else System.out.println("Doctor not found!");
    }

    public void displayAllAppointments() {
        adminService.displayAppointments();
    }

    public void displayAllPatients() {
        adminService.displayPatients();
    }

    //deleteDoctor
    public void deleteDoctor(String name) {
        boolean deleted = adminService.deleteDoctorByName(name);
        if (deleted)
            System.out.println("Doctor '" + name + "' deleted successfully");
        else
            System.out.println("Doctor '" + name + "' not found");
    }

    //deletePatient
    public void deletePatient(String name) {
        boolean deleted = adminService.deletePatientByName(name);
        if (deleted)
            System.out.println("Patient '" + name + "' deleted successfully");
        else
            System.out.println("Patient '" + name + "' not found");
    }
    
    
}
