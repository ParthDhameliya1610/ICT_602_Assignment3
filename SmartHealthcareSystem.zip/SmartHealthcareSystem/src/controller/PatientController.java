package controller;

import model.*;
import service.*;
import java.util.*;

public class PatientController {
    private PatientService patientService = new PatientService();

    public void displayAvailableDoctors() {
        List<Doctor> doctors = patientService.getAvailableDoctors();
        if (doctors.isEmpty()) {
            System.out.println("No doctors available at the moment.");
        } else {
            System.out.println("Doctor Name | Specialist | Time | Date | Available");
            for (Doctor d : doctors) {
                System.out.println(d);
            }
        }
    }

    public void bookAppointment(String patientName, String doctorName, String diagnose, String date, String time) {
        boolean booked = patientService.bookAppointment(patientName, doctorName, diagnose, date, time);
        System.out.println(booked ? "\nAppointment booked successfully" : "Doctor not available");
    }

    public void viewAppointmentHistory(String patientName) {
        patientService.viewAppointments(patientName);
    }

    public void editProfile(Patient patient, String newEmail, String newPhone, String newPassword) {
        patientService.updateProfile(patient, newEmail, newPhone, newPassword);
        System.out.println("\nProfile updated successfully");
    }

    public void rescheduleAppointment(String patientName, String doctorName, String newDate, String newTime) {
        boolean updated = patientService.rescheduleAppointmentByDoctorName(patientName, doctorName, newDate, newTime);
        System.out.println(updated ? "\nAppointment rescheduled successfully" : "Appointment not found");
    }

    public void cancelAppointment(String patientName, String doctorName) {
        boolean canceled = patientService.cancelAppointmentByDoctorName(patientName, doctorName);
        System.out.println(canceled ? "\nAppointment canceled successfully" : "Appointment not found");
    }
}
