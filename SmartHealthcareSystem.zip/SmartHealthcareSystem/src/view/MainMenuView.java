
package view;

import model.*;
import service.*;
import controller.*;

import java.time.LocalDate;
import java.util.Optional;

public class MainMenuView {

    private final ConsoleView view = new ConsoleView();
    private final AuthService authService = new AuthService();

    public void displayMainMenu() {
        view.println("\nWelcome to Smart Healthcare Appointment and Management System\n");
        while (true) {  
            view.println("\nMain Menu\n");
            view.println("1. User Sign up");
            view.println("2. User Log in");
            view.println("3. Exit Application");
            int choice = view.readInt("\nEnter Main Option: ");
            switch (choice) {
                case 1:
                    signUp();
                    break;
                case 2:
                    login();
                    break;
                case 3:
                    view.println("\nThank you for using Smart Healthcare Appointment and Management System\n");
                    return;
                default:
                    view.println("\nInvalid main menu option. Please choose correct option.");
            }
        }
    }

    private void signUp() {
        view.println("\nUser Signup");
        view.print("\nEnter User name: ");
        String name = view.readLine();
        view.print("Enter User Email: ");
        String email = view.readLine().toLowerCase();
        if (!ValidationService.isValidEmail(email)) {
            view.println("\nInvalid email format. Signup failed.");
            return;
        }
        if (authService.findUserByEmail(email).isPresent()) {
            view.println("\nEmail already registered.");
            return;
        }

        view.print("Enter Type(Admin/Doctor/Patient): ");
        String type = view.readLine().trim().toLowerCase();
        view.print("Enter phone Number: ");
        String phone = view.readLine();
        if (!ValidationService.isValidPhone(phone)) {
            view.println("\nInvalid phone number. Signup failed");
            return;
        }

        LocalDate dob = null;
        String specialist = null;
        if (type.equals("patient")) {
            dob = view.readDate("Enter Date of Birth");
        } else if (type.equals("doctor")) {
            view.print("Enter Specialist: ");
            specialist = view.readLine();
        }
        view.print("Enter password: ");
        String pass = view.readLine();
        if (pass.length() < 4) {
            view.println("\nPassword too short,password need min 4 chars. Signup failed.");
            return;
        }

        User user;
        switch (type) {
            case "admin":
                user = new Admin(name, email, phone, pass);
                break;
            case "doctor":
                user = new Doctor(name, email, phone, pass, specialist);
                break;
            case "patient":
                user = new Patient(name, email, phone, pass, dob);
                break;
            default:
                view.println("\nInvalid user type. Signup failed.");
                return;
        }
        String result = authService.registerUser(user);
        view.println(result);
    }

    private void login() {
        view.println("\nUser Login");
        view.print("\nEnter Email Address: ");
        String email = view.readLine().toLowerCase();
        view.print("Enter Password: ");
        String pass = view.readLine();
        Optional<User> maybe = authService.login(email, pass);
        if (maybe.isEmpty()) {
            view.println("\nInvalid login credentials. Login failed.");
            return;
        }
        User u = maybe.get();
        String userType = u.getClass().getSimpleName();
        view.println("\nUser Successfully Logged In: " + u.getName() + " (" + userType + ")");

        // route to role views
        if (u instanceof Admin) {
            new AdminMenuView((Admin) u).display();
        } else if (u instanceof Doctor) {
            new DoctorMenuView((Doctor) u).display();
        } else if (u instanceof Patient) {
            new PatientMenuView((Patient) u).display();
        }
    }
}
