
package view;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class ConsoleView {

    private final Scanner scanner = new Scanner(System.in);
    private final DateTimeFormatter dateFmt = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private final DateTimeFormatter timeFmt = DateTimeFormatter.ofPattern("HH:mm");

    public void println(String s) {
        System.out.println(s);
    }

    public void print(String s) {
        System.out.print(s);
    }

    public String readLine() {
        return scanner.nextLine().trim();
    }

    public int readInt(String prompt) {
        while (true) {
            try {
                print(prompt);
                String ln = readLine();
                return Integer.parseInt(ln);
            } catch (NumberFormatException ex) {
                println("Invalid number. Please try again.");
            }
        }
    }

    public java.time.LocalDate readDate(String prompt) {
        while (true) {
            try {
                print(prompt + " (yyyy-MM-dd): ");
                String ln = readLine();
                return LocalDate.parse(ln, dateFmt);
            } catch (Exception ex) {
                println("Invalid date format. Please use yyyy-MM-dd.");
            }
        }
    }

    public java.time.LocalTime readTime(String prompt) {
        while (true) {
            try {
                print(prompt + " (HH:mm): ");
                String ln = readLine();
                return LocalTime.parse(ln, timeFmt);
            } catch (Exception ex) {
                println("Invalid time format. Please use HH:mm (24-hour)");
            }
        }
    }

    public void pause() {
        println("\nPress Enter to continue");
        readLine();
    }
}
