package view;

import model.*;
import service.*;

import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

public class PatientMenuView {

    private final ConsoleView view = new ConsoleView();
    private final PatientService patientService = new PatientService();
    private final AuthService authService = new AuthService();
    private final Patient patient;

    public PatientMenuView(Patient patient) {
        this.patient = patient;
    }

    public void display() {
        while (true) {
            view.println("\nPatient Menu");
            view.println("1. Display Available Doctors");
            view.println("2. Book Appointment");
            view.println("3. View Appointment History");
            view.println("4. View Profile");
            view.println("5. Edit Profile");
            view.println("6. Reschedule Appointment");
            view.println("7. Cancel Appointment");
            view.println("8. Logout");

            int choice = view.readInt("\nEnter Patient Option: ");
            switch (choice) {
                case 1:
                    displayAvailableDoctors();
                    break;
                case 2:
                    bookAppointment();
                    break;
                case 3:
                    viewAppointmentsHistory();
                    break;
                case 4:
                    viewPatientProfile();
                    break;
                case 5:
                    editPatientProfile();
                    break;
                case 6:
                    rescheduleAppointment();
                    break;
                case 7:
                    cancelAppointment();
                    break;
                case 8: {
                    view.println("\nPatient logged out successfully.");
                    return;
                }
                default:
                    view.println("\nInvalid option. Please choose correct patient option");
            }
        }
    }

    private void displayAvailableDoctors() {
        List<Doctor> doctors = patientService.getAvailableDoctors();
        if (doctors.isEmpty()) {
            view.println("\nNo doctors available currently.");
            return;
        }

        // Header
        view.println("\nDoctor Name           | Specialist        | Time       | Date         | Available");
        view.println("--------------------------------------------------------------------------------");

        // Load availability data from DB
        List<DoctorAvailability> availabilities = InMemoryDB.getInstance().getAvailabilities();

        for (Doctor d : doctors) {
            String time = "-";
            String date = "-";
            String available = "-";

            // Find matching availability record
            Optional<DoctorAvailability> match = availabilities.stream()
                    .filter(a -> a.getDoctorEmail().equalsIgnoreCase(d.getEmail()))
                    .findFirst();

            if (match.isPresent()) {
                DoctorAvailability a = match.get();
                time = a.getTime().toString();
                date = a.getDate().toString();
                available = a.isAvailable() ? "Yes" : "No";
            }

            // Nicely formatted row
            String line = String.format(
                    "%-20s | %-17s | %-9s | %-12s | %-9s",
                    d.getName(), d.getSpecialist(), time, date, available
            );
            view.println(line);
        }

        view.pause();
    }

    private void bookAppointment() {
        view.print("\nEnter Diagnose: ");
        String diag = view.readLine();

        view.print("Enter Doctor Name: ");
        String docName = view.readLine();

        String date = view.readDate("Enter Appointment Date").format(DateTimeFormatter.ISO_LOCAL_DATE);
        String time = view.readTime("Enter Appointment Time").format(DateTimeFormatter.ISO_LOCAL_TIME);

        try {
            boolean booked = patientService.bookAppointment(patient.getEmail(), docName, diag, date, time);
            if (booked) {
                view.println("\nAppointment booked successfully with Dr. " + docName + "!");
            } else {
                view.println("\nFailed to book appointment. Doctor might be unavailable.");
            }
        } catch (Exception ex) {
            view.println("\nBooking failed: " + ex.getMessage());
        }
    }

    private void viewAppointmentsHistory() {
        view.println("\nAppointment History");
        patientService.viewAppointments(patient.getEmail());
        view.pause();
    }

    private void viewPatientProfile() {
        view.println("\nPatient Profile");
        view.println("--------------------------------------------------------------------------");
        view.println(String.format("%-20s | %-25s | %-12s | %-12s",
                "Name", "Email", "Phone", "DOB"));
        view.println("--------------------------------------------------------------------------");
        view.println(String.format("%-20s | %-25s | %-12s | %-12s",
                patient.getName(), patient.getEmail(), patient.getPhone(), patient.getDob()));
        view.pause();
    }

    private void editPatientProfile() {
        view.print("Enter new Email (or leave blank to keep): ");
        String email = view.readLine();
        if (!email.isEmpty()) {
            if (authService.findUserByEmail(email).isPresent()) {
                view.println("Email already exists. Update failed.");
                return;
            } else {
                patient.setEmail(email);
            }
        }
        view.print("Enter new Phone (or leave blank to keep): ");
        String phone = view.readLine();
        if (!phone.isEmpty()) {
            patient.setPhone(phone);
        }
        view.print("Enter new Password (or leave blank to keep): ");
        String pass = view.readLine();
        if (!pass.isEmpty()) {
            patient.setPassword(pass);
        }
        view.println("\nProfile updated successfully");
    }

    private void rescheduleAppointment() {
        view.print("\nEnter Doctor Name of appointment to reschedule: ");
        String docName = view.readLine();
        String newDate = view.readDate("Enter new Date").format(DateTimeFormatter.ISO_LOCAL_DATE);
        String newTime = view.readTime("Enter new Time").format(DateTimeFormatter.ISO_LOCAL_TIME);
        try {
            patientService.rescheduleAppointmentByDoctorName(patient.getEmail(), docName, newDate, newTime);
        } catch (Exception ex) {
            view.println("Reschedule failed: " + ex.getMessage());
        }
    }

    private void cancelAppointment() {
        view.print("Enter Doctor Name of appointment to cancel: ");
        String docName = view.readLine();
        try {
            patientService.cancelAppointmentByDoctorName(patient.getEmail(), docName);
        } catch (Exception ex) {
            view.println("Cancellation failed: " + ex.getMessage());
        }
    }

}
