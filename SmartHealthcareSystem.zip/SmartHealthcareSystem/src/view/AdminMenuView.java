package view;

import model.*;
import service.*;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

public class AdminMenuView {

    private final ConsoleView view = new ConsoleView();
    private final AdminService adminService = new AdminService();
    private final AuthService authService = new AuthService();
    private final Admin admin;

    public AdminMenuView(Admin admin) {
        this.admin = admin;
    }

    public void display() {
        while (true) {
            view.println("\nAdmin Menu");
            view.println("1. Display All Doctors");
            view.println("2. Add Doctor Availability");
            view.println("3. Display All appointments");
            view.println("4. Display All Patients");
            view.println("5. Delete Doctor");
            view.println("6. Delete Patient");
            view.println("7. Logout");
            int choice = view.readInt("\nEnter Admin Option: ");
            switch (choice) {
                case 1:
                    displayDoctors();
                    break;
                case 2:
                    addDoctorAvailability();
                    break;
                case 3:
                    displayAppointments();
                    break;
                case 4:
                    displayPatients();
                    break;
                case 5:
                    deleteDoctor();
                    break;
                case 6:
                    deletePatient();
                    break;
                case 7:
                    view.println("\nAdmin logged out successfully.");
                    return;
                default:
                    view.println("\nInvalid Admin menu option. Please choose correct option");
            }
        }
    }

    private void displayDoctors() {
        List<Doctor> doctors = adminService.getAllDoctors();
        List<DoctorAvailability> availabilities = InMemoryDB.getInstance().getAvailabilities();

        view.println("\nDoctor Name           | Specialist        | Time       | Date         | Available");
        view.println("--------------------------------------------------------------------------------");

        for (Doctor d : doctors) {
            Optional<DoctorAvailability> match = availabilities.stream()
                    .filter(a -> a.getDoctorEmail().equalsIgnoreCase(d.getEmail()))
                    .findFirst();

            String time = "-";
            String date = "-";
            String available = "-";

            if (match.isPresent()) {
                DoctorAvailability a = match.get();
                time = a.getTime().toString();
                date = a.getDate().toString();
                available = a.isAvailable() ? "Yes" : "No";
            }

            // Consistent column widths
            String line = String.format(
                    "%-20s | %-17s | %-9s | %-12s | %-9s",
                    d.getName(), d.getSpecialist(), time, date, available
            );
            view.println(line);
        }
        view.pause();
    }

    private void addDoctorAvailability() {
        view.print("\nEnter Doctor Email: ");
        String email = view.readLine();
        try {
            view.print("Enter Available: ");
            java.time.LocalTime t = view.readTime("Time");
            java.time.LocalDate d = view.readDate("Enter Available Date");
            adminService.addDoctorAvailability(email, t, d);
            view.println("\nAvailability added for " + email);
        } catch (Exception ex) {
            view.println("Error: " + ex.getMessage());
        }
    }

    private void displayAppointments() {
        List<Appointment> appts = adminService.getAllAppointments();
        if (appts.isEmpty()) {
            view.println("\nNo appointments found.");
            return;
        }

        view.println("\n--------------------------------------------------------------------------------------------");
        view.println(String.format("%-20s %-20s %-20s %-20s %-12s %-8s",
                "Patient Name", "Doctor Name", "Diagnose", "Prescription", "Date", "Time"));
        view.println("--------------------------------------------------------------------------------------------");

        for (Appointment a : appts) {
            String pName = authService.findUserByEmail(a.getPatientEmail())
                    .map(User::getName)
                    .orElse(a.getPatientEmail());
            String dName = authService.findUserByEmail(a.getDoctorEmail())
                    .map(User::getName)
                    .orElse(a.getDoctorEmail());

            view.println(String.format("%-20s %-20s %-20s %-20s %-12s %-8s",
                    pName,
                    dName,
                    (a.getDiagnose() == null || a.getDiagnose().isBlank()) ? "-" : a.getDiagnose(),
                    (a.getPrescription() == null || a.getPrescription().isBlank()) ? "-" : a.getPrescription(),
                    (a.getDate() == null) ? "-" : a.getDate().toString(),
                    (a.getTime() == null) ? "-" : a.getTime().toString()));
        }

        view.println("--------------------------------------------------------------------------------------------");
        view.pause();
    }

    private void displayPatients() {
        List<Patient> patients = adminService.getAllPatients();
        view.println("\nPatient Name           | Email                     | Phone       | DOB");
        view.println("--------------------------------------------------------------------------------");
        for (Patient p : patients) {
            view.println(p.toString());
        }
        view.pause();
    }

    private void deleteDoctor() {
        view.print("\nEnter Doctor Name to delete: ");
        String name = view.readLine();
        boolean deleted = adminService.deleteDoctorByName(name);
        if (deleted) {
            view.println("\nDoctor deleted successfully.");
        } else {
            view.println("\nDoctor not found.");
        }
    }

    private void deletePatient() {
        view.print("\nEnter Patient Name to delete: ");
        String name = view.readLine();
        boolean deleted = adminService.deletePatientByName(name);
        if (deleted) {
            view.println("\nPatient deleted successfully.");
        } else {
            view.println("\nPatient not found.");
        }
    }
}
