package view;

import model.*;
import service.*;

import java.util.List;

public class DoctorMenuView {

    private final ConsoleView view = new ConsoleView();
    private final DoctorService doctorService = new DoctorService();
    private final AuthService authService = new AuthService();
    private final Doctor doctor;

    public DoctorMenuView(Doctor doctor) {
        this.doctor = doctor;
    }

    public void display() {
        while (true) {
            view.println("\nDoctor Menu");
            view.println("1. View Patients");
            view.println("2. Add/Update Prescription");
            view.println("3. Logout");
            int choice = view.readInt("Enter Doctor Option: ");
            switch (choice) {
                case 1:
                    viewPatients();
                    break;
                case 2:
                    addOrUpdatePrescription();
                    break;
                case 3:
                    view.println("\nDoctor logged out successfully.");
                    return;
                default:
                    view.println("\nInvalid Doctor menu option. Please choose corrct doctor option");
            }
        }
    }

    private void viewPatients() {
        List<Appointment> list = doctorService.getAppointmentsForDoctor(doctor.getEmail());
        if (list.isEmpty()) {
            view.println("No patients scheduled.");
            return;
        }

        view.println("\n--------------------------------------------------------------------------------------------");
        view.println(String.format("%-20s %-20s %-15s %-15s %-20s",
                "Patient Name", "Diagnose", "Time", "Date", "Prescription"));
        view.println("--------------------------------------------------------------------------------------------");

        for (Appointment a : list) {
            String pName = authService.findUserByEmail(a.getPatientEmail())
                    .map(User::getName)
                    .orElse(a.getPatientEmail());
            view.println(String.format("%-20s %-20s %-15s %-15s %-20s",
                    pName, a.getDiagnose(), a.getTime(), a.getDate(),
                    (a.getPrescription() == null || a.getPrescription().isBlank()) ? "-" : a.getPrescription()));
        }
        view.println("--------------------------------------------------------------------------------------------");
        view.pause();
    }

    private void addOrUpdatePrescription() {
        view.print("Enter Patient Email: ");
        String pEmail = view.readLine();
        view.print("Enter Prescription: ");
        String pres = view.readLine();
        try {
            doctorService.addOrUpdatePrescription(doctor.getEmail(), pEmail, pres);
            view.println("");
        } catch (Exception ex) {
            view.println("Failed: " + ex.getMessage());
        }
    }
}
