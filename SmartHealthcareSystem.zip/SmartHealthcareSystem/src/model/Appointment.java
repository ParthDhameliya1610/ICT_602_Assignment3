package model;

import java.time.LocalDate;
import java.time.LocalTime;

public class Appointment {

    private final String patientEmail;
    private final String doctorEmail;
    private final String diagnose;
    private LocalDate date;
    private LocalTime time;
    private String prescription = "";

    public Appointment(String patientEmail, String doctorEmail, String diagnose, LocalDate date, LocalTime time) {
        this.patientEmail = patientEmail.toLowerCase();
        this.doctorEmail = doctorEmail.toLowerCase();
        this.diagnose = diagnose;
        this.date = date;
        this.time = time;
    }

    public String getPatientEmail() {
        return patientEmail;
    }

    public String getDoctorEmail() {
        return doctorEmail;
    }

    public String getDiagnose() {
        return diagnose;
    }

    public LocalDate getDate() {
        return date;
    }

    public LocalTime getTime() {
        return time;
    }

    public String getPrescription() {
        return prescription;
    }

    public void setPrescription(String prescription) {
        this.prescription = prescription;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public void setTime(LocalTime time) {
        this.time = time;
    }
}
