
package model;



import java.time.LocalDate;

public class Patient extends User {
    private LocalDate dob;

    public Patient(String name, String email, String phone, String password, LocalDate dob) {
        super(name, email, phone, password);
        this.dob = dob;
    }

    public LocalDate getDob() { return dob; }
    public void setDob(LocalDate dob) { this.dob = dob; }

    @Override
    public String toString() {
        return String.format("%-20s | %-25s | %-12s | %-12s", name, email, phone, dob == null ? "-" : dob.toString());
    }
}
