package model;

public abstract class User {

    protected String name;
    protected String email;
    protected String phone;
    protected String password;

    public User(String name, String email, String phone, String password) {
        this.name = name;
        this.email = email.toLowerCase();
        this.phone = phone;
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getPhone() {
        return phone;
    }

    public String getPassword() {
        return password;
    }

    public void setEmail(String email) {
        this.email = email.toLowerCase();
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
