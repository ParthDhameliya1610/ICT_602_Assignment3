
package model;

import java.util.ArrayList;
import java.util.List;

public class Doctor extends User {

    private String specialist;
    private final List<DoctorAvailability> availabilities = new ArrayList<>();

    public Doctor(String name, String email, String phone, String password, String specialist) {
        super(name, email, phone, password);
        this.specialist = specialist;
    }

    public String getSpecialist() {
        return specialist;
    }

    public List<DoctorAvailability> getAvailabilities() {
        return availabilities;
    }

    public void addAvailability(DoctorAvailability a) {
        availabilities.add(a);
    }

    @Override
    public String toString() {
        if (availabilities.isEmpty()) {
            return String.format("%-20s | %-15s | %-12s | %-12s | %-8s",
                    name, specialist, "-", "-", "-");
        } else {
            StringBuilder sb = new StringBuilder();
            for (DoctorAvailability a : availabilities) {
                sb.append(String.format("%-20s | %-15s | %-12s | %-12s | %-8s\n",
                        name, specialist, a.getTime().toString(), a.getDate().toString(), a.isAvailable() ? "Yes" : "Booked"));
            }
            return sb.toString().trim();
        }
    }
}
