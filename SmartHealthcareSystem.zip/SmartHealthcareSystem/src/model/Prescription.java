
package model;



public class Prescription {
    private final String patientEmail;
    private final String doctorEmail;
    private final String text;

    public Prescription(String patientEmail, String doctorEmail, String text) {
        this.patientEmail = patientEmail.toLowerCase();
        this.doctorEmail = doctorEmail.toLowerCase();
        this.text = text;
    }
}

