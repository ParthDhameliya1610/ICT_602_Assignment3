package model;

import java.time.LocalDate;
import java.time.LocalTime;

public class DoctorAvailability {
    private final String doctorEmail;
    private final LocalTime time;
    private final LocalDate date;
    private boolean available = true;

    
    public DoctorAvailability(String doctorEmail, LocalTime time, LocalDate date) {
        this.doctorEmail = doctorEmail.toLowerCase();
        this.time = time;
        this.date = date;
        this.available = true;
    }

    
    public DoctorAvailability(String doctorEmail, LocalTime time, LocalDate date, boolean available) {
        this.doctorEmail = doctorEmail.toLowerCase();
        this.time = time;
        this.date = date;
        this.available = available;
    }

    public String getDoctorEmail() { return doctorEmail; }
    public LocalTime getTime() { return time; }
    public LocalDate getDate() { return date; }
    public boolean isAvailable() { return available; }
    public void setAvailable(boolean available) { this.available = available; }

    @Override
    public String toString() {
        return String.format("%s | %s | %s | %s",
                doctorEmail, time, date, (available ? "Yes" : "No"));
    }
}
